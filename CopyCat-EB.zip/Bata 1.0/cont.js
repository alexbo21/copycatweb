// cat 1
function cat1(){
 var cat1 = document.getElementById("cat1");
cat1.select();
document.execCommand("copy");
};
// cat 2
function cat2(){
 var cat2 = document.getElementById("cat2");
cat2.select();
document.execCommand("copy");
};

//cat 3

function cat3(){
 var cat3 = document.getElementById("cat3");
cat3.select();
document.execCommand("copy");
};

//cat 4
function cat4(){
 var cat4 = document.getElementById("cat4");
cat4.select();
document.execCommand("copy");
};

// cat 5

function cat5(){
 var cat5 = document.getElementById("cat5");
cat5.select();
document.execCommand("copy");
};

// cat 6

function cat6(){
 var cat6 = document.getElementById("cat6");
cat6.select();
document.execCommand("copy");
};
