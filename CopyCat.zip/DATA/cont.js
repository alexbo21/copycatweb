// cat 1
function cat1(){
 var cat1 = document.getElementById("cat1");
cat1.select();
document.execCommand("copy");
};
// cat 2
function cat2(){
 var cat2 = document.getElementById("cat2");
cat2.select();
document.execCommand("copy");
};

//cat 3

function cat3(){
 var cat3 = document.getElementById("cat3");
cat3.select();
document.execCommand("copy");
};

//cat 4
function cat4(){
 var cat4 = document.getElementById("cat4");
cat4.select();
document.execCommand("copy");
};

// cat 5

function cat5(){
 var cat5 = document.getElementById("cat5");
cat5.select();
document.execCommand("copy");

};

// cat 6

function cat6(){
 var cat6 = document.getElementById("cat6");
cat6.select();
document.execCommand("copy");
};
// cat 7
function cat7(){
 var cat7 = document.getElementById("cat7");
cat7.select();
document.execCommand("copy");
};
// cat 8
function cat8(){
 var cat8 = document.getElementById("cat8");
cat8.select();
document.execCommand("copy");
};
// cat 9
function cat9(){
 var cat9 = document.getElementById("cat9");
cat9.select();
document.execCommand("copy");
};

// cat 10
function cat10(){
 var cat10 = document.getElementById("cat10");
cat10.select();
document.execCommand("copy");
};

// extraCats Expansion Code

//cat 11
function cat11(){
 var cat11 = document.getElementById("cat11");
cat11.select();
document.execCommand("copy");
};

//cat 12
function cat12(){
 var cat12 = document.getElementById("cat12");
cat12.select();
document.execCommand("copy");
};

//cat 13
function cat13(){
 var cat13 = document.getElementById("cat13");
cat13.select();
document.execCommand("copy");
};

//cat 14
function cat14(){
 var cat14 = document.getElementById("cat14");
cat14.select();
document.execCommand("copy");
};

//cat 15
function cat15(){
 var cat15 = document.getElementById("cat15");
cat15.select();
document.execCommand("copy");
};

//cat 16
function cat16(){
 var cat16 = document.getElementById("cat16");
cat16.select();
document.execCommand("copy");
};

//cat 17
function cat17(){
 var cat17 = document.getElementById("cat17");
cat17.select();
document.execCommand("copy");
};

//cat 18
function cat18(){
 var cat18 = document.getElementById("cat18");
cat18.select();
document.execCommand("copy");
};

//cat 19
function cat19(){
 var cat19 = document.getElementById("cat19");
cat19.select();
document.execCommand("copy");
};

//cat 20
function cat20(){
 var cat20 = document.getElementById("cat20");
cat20.select();
document.execCommand("copy");
};

function extraCatCheck(cat20){
  alert(cat20);

}

function callClip(){
  alert("desplaying clipboards at end of website");
  document.getElementById("clipCheck").innerHTML = "hello";
};





//this program is deticated to my cat, Gaston
